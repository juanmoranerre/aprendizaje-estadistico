```python
import pandas as pd
df = pd.read_csv("bateria_tableta.txt")
df.shape
```




    (100, 2)




```python
import matplotlib.pyplot as plt
plt.figure ()
plt.scatter(df["carga"], df["duracion"])
```




    <matplotlib.collections.PathCollection at 0x1d748d6f620>




    
![png](output_1_1.png)
    



```python
import numpy as np
x_v =np.reshape(df["carga"], (100,1)) #es un vector
x_2v = x_v**2
ones = np.ones([100,1]) #shape
X = np.hstack([x_v,x_2v]) #X mayuscula
```


```python
from sklearn.linear_model import LinearRegression
lr = LinearRegression()
lr.fit(X,df["duracion"])
print(lr.intercept_)
print(lr.coef_)

```

    0.1091917907649469
    [ 2.34328352 -0.16141513]
    


```python
def f(x):
    y = 0.1091 + 2.3432*x - 0.1614*x**2
    return y

f(df["carga"])

```




    0     5.419061
    1     8.611441
    2     5.288502
    3     6.760012
    4     3.978526
            ...   
    95    7.275954
    96    8.510167
    97    8.512737
    98    2.491326
    99    8.553869
    Name: carga, Length: 100, dtype: float64




```python
plt.figure()
plt.scatter(df["carga"], f(df["carga"]))
```




    <matplotlib.collections.PathCollection at 0x1d74d4e3c50>




    
![png](output_5_1.png)
    



```python
lr.predict(X)
```




    array([5.41926846, 8.61135732, 5.28870926, 6.76020073, 3.97872185,
           8.56274627, 8.60443988, 8.11444344, 8.03615771, 7.69271601,
           8.50470983, 8.15882775, 8.04830541, 0.43408775, 4.1500983 ,
           8.09726665, 1.88051292, 7.26681216, 8.00075011, 0.10919179,
           3.76880875, 6.27227633, 8.40803953, 6.36960481, 7.48131831,
           3.73337127, 8.49185472, 0.1559929 , 7.65935784, 8.01326664,
           8.48618219, 8.14242575, 8.56630668, 4.25137459, 8.56803847,
           4.54823031, 7.64359444, 2.51135691, 8.41062697, 4.69273578,
           3.8568375 , 8.33298898, 8.0052235 , 2.5707599 , 7.0538463 ,
           8.39212173, 8.21140266, 8.46750787, 3.71560411, 4.41758576,
           7.73840093, 8.24628426, 2.80546636, 6.86797962, 7.2853979 ,
           8.6017335 , 4.11608128, 3.5542469 , 4.21774496, 5.40075055,
           7.50682412, 7.56520776, 6.64919354, 7.92101745, 3.8568375 ,
           4.40110991, 3.40862302, 7.9475081 , 2.82481539, 8.3688501 ,
           8.05004144, 6.29680215, 8.51578309, 7.01344652, 3.89182301,
           8.23505912, 0.41109073, 3.14880964, 8.34143785, 6.23524549,
           3.96140665, 4.11608128, 7.96889383, 0.99852112, 8.37785976,
           4.13310593, 3.40862302, 6.88914801, 7.24809728, 8.56505321,
           5.08041959, 8.61162181, 8.25595989, 6.86797962, 6.51172355,
           7.27612117, 8.50994897, 8.51252011, 2.49149135, 8.55384657])




```python
Realiza regresiones polinomiales de orden 1, 5, y 9
```


```python

x_3v = x_v**3
x_4v = x_v**4
x_5v = x_v**5
x_6v = x_v**6
x_7v = x_v**7
x_8v = x_v**8
x_9v = x_v**9

X1 = x_v
X5 = np.hstack([x_v, x_2v, x_3v, x_4v, x_5v])
X9 = np.hstack([x_v, x_2v, x_3v, x_4v, x_5v, x_6v, x_7v, x_8v, x_9v])
```


```python
lr1 = LinearRegression()
lr1.fit(X1, df["duracion"])
print(lr1.intercept_)
print(lr1.coef_)

lr5 = LinearRegression()
lr5.fit(X5, df["duracion"])
print(lr5.intercept_)
print(lr5.coef_)

lr9 = LinearRegression()
lr9.fit(X9, df["duracion"])
print(lr9.intercept_)
print(lr9.coef_)
```

    2.8705411116210198
    [0.72955585]
    0.1427624486349952
    [ 8.35890085e-01  1.10347381e+00 -3.23550360e-01  3.20123836e-02
     -1.07054199e-03]
    3.9372068687088824
    [ 1.96215281e-06  1.18357228e-05  5.63133538e-05  2.27505603e-04
      7.30461439e-04  1.42491439e-03 -4.83193244e-04  5.07961750e-05
     -1.74034242e-06]
    


```python
Crea una gráfica con una nube de dispersión (datos originales) y tus modelos.
    
```


```python
plt.figure()
plt.scatter(df["carga"], df["duracion"], label="Datos originales")
plt.scatter(df["carga"], lr1.predict(X1), label="Orden 1")
plt.scatter(df["carga"], lr5.predict(X5), label="Orden 5")
plt.scatter(df["carga"], lr9.predict(X9), label="Orden 9")
plt.xlabel("carga")
plt.ylabel("duracion")
plt.legend()
```




    <matplotlib.legend.Legend at 0x1d74d5827b0>




    
![png](output_11_1.png)
    



```python
ds = pd.read_csv("Salarios_minimos.csv")
ds.shape
```




    (34, 2)




```python
Realiza regresiones polinomiales de orden 1, 5, y 9
```


```python
t_v = np.reshape(ds["Periodo"] - 1988, (34,1))   # años desde 1988
t_2v = t_v**2
t_3v = t_v**3
t_4v = t_v**4
t_5v = t_v**5
t_6v = t_v**6
t_7v = t_v**7
t_8v = t_v**8
t_9v = t_v**9

T1 = t_v
T5 = np.hstack([t_v, t_2v, t_3v, t_4v, t_5v])
T9 = np.hstack([t_v, t_2v, t_3v, t_4v, t_5v, t_6v, t_7v, t_8v, t_9v])
```


```python
s1 = LinearRegression()
s1.fit(T1, ds["Salario"])
print(s1.intercept_)
print(s1.coef_)

s5 = LinearRegression()
s5.fit(T5, ds["Salario"])
print(s5.intercept_)
print(s5.coef_)

s9 = LinearRegression()
s9.fit(T9, ds["Salario"])
print(s9.intercept_)
print(s9.coef_)
```

    3.715577808507625
    [2.52832885]
    11.068137889940765
    [ 3.60437066e-04  4.40312886e-03  3.28074670e-02 -2.12200208e-03
      3.73657428e-05]
    21.282094200448277
    [ 2.01299096e-14  4.49861826e-13  8.35699792e-12  1.40738708e-10
      2.12414318e-09  2.68110304e-08  2.26734064e-07 -1.54558698e-08
      2.65970414e-10]
    


```python
 Crea una gráfica con una nube de dispersión (datos originales) y tus modelos.
```


```python
plt.figure()
plt.scatter(ds["Periodo"], ds["Salario"], label="Datos originales")
plt.scatter(ds["Periodo"], s1.predict(T1), label="Orden 1")
plt.scatter(ds["Periodo"], s5.predict(T5), label="Orden 5")
plt.scatter(ds["Periodo"], s9.predict(T9), label="Orden 9")
plt.xlabel("Periodo")
plt.ylabel("Salario")
```




    Text(0, 0.5, 'Salario')




    
![png](output_17_1.png)
    

